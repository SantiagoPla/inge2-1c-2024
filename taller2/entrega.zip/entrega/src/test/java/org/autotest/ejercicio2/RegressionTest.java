package org.autotest.ejercicio2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ RegressionTest0.class, RegressionTest1.class, RegressionTest2.class, RegressionTest3.class, RegressionTest4.class, RegressionTest5.class, RegressionTest6.class, RegressionTest7.class, RegressionTest8.class, RegressionTest9.class, RegressionTest10.class, RegressionTest11.class, RegressionTest12.class, RegressionTest13.class, RegressionTest14.class, RegressionTest15.class, RegressionTest16.class, RegressionTest17.class, RegressionTest18.class, RegressionTest19.class, RegressionTest20.class, RegressionTest21.class, RegressionTest22.class, RegressionTest23.class, RegressionTest24.class, RegressionTest25.class, RegressionTest26.class, RegressionTest27.class, RegressionTest28.class, RegressionTest29.class, RegressionTest30.class, RegressionTest31.class, RegressionTest32.class, RegressionTest33.class, RegressionTest34.class, RegressionTest35.class, RegressionTest36.class, RegressionTest37.class })
public class RegressionTest {
}

